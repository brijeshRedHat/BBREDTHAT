const authors = [
  {
    id: 1,
    name: 'James Joyce',
    dob: 1882
  },
  {
    id: 2,
    name: 'F Scott Fitzgerald',
    dob: 1896
  },
  {
    id: 3,
    name: 'Aldous Huxley',
    dob: 1894
  },
  {
    id: 4,
    name: 'Vladimir Nabokov',
    dob: 1899
  },
  {
    id: 5,
    name: 'William Faulkner',
    dob: 1897
  }
];

module.exports.books = authors;
